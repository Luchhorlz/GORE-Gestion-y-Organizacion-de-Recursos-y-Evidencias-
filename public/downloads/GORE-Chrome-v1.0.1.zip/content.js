(() => {
  if (window.top !== window || document.getElementById('gore-capture-root')) return
  const VERSION = '1.0.1'
  const state = { bubbles: [], allBubbles: [], observedSources: new Map(), lastVoiceBubble: null, busy: false, cancelled: false }
  const voiceControlSelector = 'button[aria-label*="Reproducir" i],button[aria-label*="Play" i],[data-icon="audio-play"],[data-icon="audio-pause"],[data-testid*="audio-play"],[data-testid*="audio-pause"]'
  const encoder = new TextEncoder()
  const hex = buffer => Array.from(new Uint8Array(buffer), value => value.toString(16).padStart(2, '0')).join('')
  const digest = async value => hex(await crypto.subtle.digest('SHA-256', typeof value === 'string' ? encoder.encode(value) : value))
  const slug = value => (value || 'chat').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase().slice(0, 50) || 'chat'
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
  function chatName() {
    const header = document.querySelector('#main header,[data-testid="conversation-panel-wrapper"] header,header')
    return header?.querySelector('[title]')?.getAttribute('title') || header?.querySelector('[dir="auto"]')?.textContent?.trim() || 'Chat de WhatsApp'
  }
  function bubbleFor(element) { return element?.closest('[data-id]') || element?.closest('[data-testid="msg-container"]') || element?.closest('[role="row"]') || element?.closest('.message-in,.message-out') || element?.parentElement?.parentElement?.parentElement }
  function metadata(bubble, position) {
    if (!bubble) return { sender: 'Contacto', visibleTimestamp: null, direction: 'incoming', position: -1 }
    const copyable = bubble.querySelector('[data-pre-plain-text]')
    const pre = copyable?.getAttribute('data-pre-plain-text') || ''
    const match = pre.match(/^\[([^\]]+)]\s*([^:]+):/)
    const incoming = Boolean(bubble.closest('.message-in') || bubble.classList.contains('message-in'))
    return { sender: match?.[2]?.trim() || (incoming ? 'Contacto' : 'Yo'), visibleTimestamp: match?.[1]?.trim() || null, direction: incoming ? 'incoming' : 'outgoing', position }
  }
  function analyze() {
    const seenMessages = new Set()
    state.allBubbles = Array.from(document.querySelectorAll('[data-id],[data-testid="msg-container"],[role="row"]')).filter(bubble => (bubble.querySelector('[data-pre-plain-text]') || bubble.querySelector('audio') || bubble.querySelector(voiceControlSelector)) && !seenMessages.has(bubble) && seenMessages.add(bubble))
    const seenAudio = new Set()
    const elements = [...document.querySelectorAll('audio'), ...document.querySelectorAll(voiceControlSelector), ...state.observedSources.keys()]
    state.bubbles = elements.map(element => {
      const bubble = element.matches?.('audio') ? bubbleFor(element) : element.matches?.('[data-id],[data-testid="msg-container"],[role="row"],.message-in,.message-out') ? element : bubbleFor(element)
      const audio = bubble?.querySelector('audio') || (element.matches?.('audio') ? element : null)
      return { audio, bubble, source: state.observedSources.get(bubble) || audio?.currentSrc || audio?.src || '', ...metadata(bubble, state.allBubbles.indexOf(bubble) + 1) }
    }).filter(item => item.bubble && item.position > 0 && !seenAudio.has(item.bubble) && seenAudio.add(item.bubble))
    document.getElementById('gore-found').textContent = String(state.bubbles.length)
    setStatus(state.bubbles.length ? `${state.bubbles.length} notas de voz cargadas actualmente en el chat.` : 'No encontramos notas de voz cargadas. Desplazate por el chat para cargar los audios y volvé a analizar.')
  }
  function setStatus(text) { document.getElementById('gore-capture-status').textContent = text }
  function setProgress(done, total) { document.getElementById('gore-processed').textContent = String(done); document.querySelector('.gore-progress span').style.width = `${total ? done / total * 100 : 0}%` }
  async function capture() {
    if (state.busy) return
    analyze()
    if (!state.bubbles.length) return
    state.busy = true; state.cancelled = false
    document.getElementById('gore-export').disabled = true
    document.getElementById('gore-cancel').disabled = false
    const zip = new JSZip(); const media = []; const messages = []; const errors = []
    const displayName = chatName(); const stableKey = (await digest(displayName)).slice(0, 24)
    const audioBubbles = new Set(state.bubbles.map(item => item.bubble))
    for (let position = 1; position <= state.allBubbles.length; position++) {
      const bubble = state.allBubbles[position - 1]
      if (audioBubbles.has(bubble)) continue
      const info = metadata(bubble, position); const copyable = bubble.querySelector('[data-pre-plain-text]'); const text = copyable?.textContent?.trim() || null
      messages.push({ id: `msg-${stableKey}-${String(position).padStart(6, '0')}`, position, sender: info.sender, direction: info.direction, visibleTimestamp: info.visibleTimestamp, type: 'text', text, mediaId: null, associationStatus: 'CAPTURED_FROM_SPECIFIC_BUBBLE', associationEvidence: ['message-order-observed-in-open-chat'] })
    }
    for (let index = 0; index < state.bubbles.length; index++) {
      if (state.cancelled) break
      const item = state.bubbles[index]; item.bubble.classList.add('gore-current'); item.bubble.scrollIntoView({ block: 'center' }); await sleep(180)
      const messageId = `msg-${stableKey}-${String(item.position).padStart(6, '0')}`
      try {
        const source = state.observedSources.get(item.bubble) || item.source || item.audio?.currentSrc || item.audio?.src
        if (!source) throw new Error('Reproducí este audio una vez para autorizar su lectura y volvé a crear el paquete')
        const response = await fetch(source); if (!response.ok) throw new Error(`No se pudo leer el audio (${response.status})`)
        const buffer = await response.arrayBuffer(); if (!buffer.byteLength) throw new Error('Audio vacío')
        const hash = await digest(buffer); const mime = response.headers.get('content-type') || 'audio/ogg'; const extension = mime.includes('mpeg') ? 'mp3' : mime.includes('mp4') ? 'm4a' : 'ogg'
        const exportedFilename = `media/${String(index + 1).padStart(6, '0')}__voice.${extension}`; const mediaId = `media-${hash.slice(0, 20)}`
        zip.file(exportedFilename, buffer); media.push({ id: mediaId, originalFilename: `WhatsApp-voice-${index + 1}.${extension}`, exportedFilename, mimeType: mime, size: buffer.byteLength, durationMs: Number.isFinite(item.audio?.duration) ? Math.round(item.audio.duration * 1000) : null, sha256: hash })
        messages.push({ id: messageId, position: item.position, sender: item.sender, direction: item.direction, visibleTimestamp: item.visibleTimestamp, type: 'voice_note', text: null, mediaId, associationStatus: 'CAPTURED_FROM_SPECIFIC_BUBBLE', associationEvidence: ['audio-read-from-specific-rendered-bubble', 'sequential-capture-single-item', 'sha256-calculated-before-package'] })
      } catch (error) {
        errors.push({ messageId, error: String(error?.message || error) }); messages.push({ id: messageId, position: item.position, sender: item.sender, direction: item.direction, visibleTimestamp: item.visibleTimestamp, type: 'voice_note', text: null, mediaId: null, associationStatus: 'UNSUPPORTED', associationEvidence: ['specific-bubble-detected', 'audio-content-not-readable'] })
      } finally { item.bubble.classList.remove('gore-current'); setProgress(index + 1, state.bubbles.length) }
    }
    messages.sort((left, right) => left.position - right.position)
    const manifest = { schemaVersion: 1, createdAt: new Date().toISOString(), source: { application: 'WhatsApp Web', extractionMethod: 'chrome_extension', extensionVersion: VERSION }, chat: { stableKey, displayName, isGroup: false }, messages, media }
    zip.file('manifest.json', JSON.stringify(manifest, null, 2)); zip.file('checksums.json', JSON.stringify(Object.fromEntries(media.map(item => [item.exportedFilename, item.sha256])), null, 2)); zip.file('logs/extraction-summary.json', JSON.stringify({ captured: media.length, errors, cancelled: state.cancelled }, null, 2))
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } }); const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = `gore-whatsapp-${slug(displayName)}-${new Date().toISOString().slice(0, 10)}.zip`; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 30000)
    setStatus(`Paquete creado: ${media.length} audios capturados, ${errors.length} errores.${state.cancelled ? ' Proceso cancelado parcialmente.' : ''}`); state.busy = false; document.getElementById('gore-export').disabled = false; document.getElementById('gore-cancel').disabled = true
  }
  const root = document.createElement('section'); root.id = 'gore-capture-root'; root.innerHTML = `<header><strong>GORE · Captura verificable</strong><button id="gore-minimize" title="Minimizar">−</button></header><div id="gore-capture-body"><p>Procesa localmente solamente el chat abierto. No lee cookies ni envía mensajes.</p><div class="gore-stats"><div class="gore-stat"><strong id="gore-found">0</strong>audios encontrados</div><div class="gore-stat"><strong id="gore-processed">0</strong>procesados</div></div><div class="gore-progress"><span></span></div><div class="gore-actions"><button id="gore-analyze">Analizar chat</button><button class="primary" id="gore-export">Crear paquete GORE</button><button id="gore-cancel" disabled>Cancelar</button></div><div id="gore-capture-status">Abrí un chat y pulsá “Analizar chat”.</div></div>`; document.body.appendChild(root)
  document.addEventListener('click', event => { const control = event.target.closest?.(voiceControlSelector); if (control) state.lastVoiceBubble = bubbleFor(control) }, true)
  document.addEventListener('play', event => { const audio = event.target; if (!(audio instanceof HTMLMediaElement)) return; const bubble = bubbleFor(audio) || state.lastVoiceBubble; const source = audio.currentSrc || audio.src; if (bubble && source) { state.observedSources.set(bubble, source); state.lastVoiceBubble = null } }, true)
  document.getElementById('gore-analyze').addEventListener('click', analyze); document.getElementById('gore-export').addEventListener('click', capture); document.getElementById('gore-cancel').addEventListener('click', () => { state.cancelled = true; setStatus('Cancelando después del audio actual…') }); document.getElementById('gore-minimize').addEventListener('click', event => { const body = document.getElementById('gore-capture-body'); body.hidden = !body.hidden; event.currentTarget.textContent = body.hidden ? '+' : '−' })
})()
